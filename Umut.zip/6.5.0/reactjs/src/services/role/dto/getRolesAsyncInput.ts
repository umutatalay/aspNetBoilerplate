export interface GetRoleAsyncInput {
  permission: string;
}
