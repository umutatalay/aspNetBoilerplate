export default class GetTenantOutput {
  tenancyName!: string;
  name!: string;
  isActive!: boolean;
  id!: number;
}
