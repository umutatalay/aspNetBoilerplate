import TenantAvailabilityState from './tenantAvailabilityState';

export default class IsTenantAvaibleOutput {
  state!: TenantAvailabilityState;
  tenantId!: number;
}
