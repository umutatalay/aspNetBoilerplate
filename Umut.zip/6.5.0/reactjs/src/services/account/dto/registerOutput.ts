export interface RegisterOutput {
  canLogin: boolean;
}
